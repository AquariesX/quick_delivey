'use client'

import MaterialCustomerDashboard from '@/components/customer/MaterialCustomerDashboard'

const MaterialCustomerPage = () => {
  return <MaterialCustomerDashboard />
}

export default MaterialCustomerPage
